# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 302 | 0.83971 / 0.82941 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 302 | 4.4583 / 4.2465 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 302 | 0.57182 / 0.55539 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 302 | 4.303 / 3.9652 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 302 | 0.61085 / 0.60767 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 302 | 4.405 / 4.3906 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 302 | 5.0297 / 4.9991 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 302 | 4.7084 / 4.7835 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 302 | 1.0536 / 1.0169 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 302 | 4.4116 / 4.3936 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 302 | 0.70919 / 0.70933 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 302 | 4.7238 / 4.7279 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 302 | 0.94142 / 0.94193 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 302 | 4.4395 / 4.2499 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 302 | 0.6133 / 0.6077 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 302 | 1.0355 / 1.011 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 302 | 4.292 / 3.9652 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 302 | 0.71507 / 0.70911 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 302 | 0.55243 / 0.55572 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 302 | 5.0291 / 5.0385 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 302 | 4.7242 / 4.7279 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 302 | 0.82919 / 0.82941 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 302 | 0.94515 / 0.9427 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 302 | 4.701 / 4.7831 | 0.2222222222222222 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
