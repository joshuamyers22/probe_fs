# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 309 | 4.6623 / 4.6645 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 309 | 0.59795 / 0.59777 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 309 | 1.0106 / 1.0202 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 309 | 1.0087 / 1.0202 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 309 | 0.64184 / 0.64176 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 309 | 0.63898 / 0.65162 | 0.22222222222222232 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 309 | 4.6049 / 4.6032 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 309 | 0.92152 / 0.90931 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 309 | 5.3628 / 5.4745 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 309 | 0.59803 / 0.60361 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 309 | 1.0293 / 1.0392 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 309 | 4.3734 / 4.3704 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 309 | 4.7688 / 4.7575 | 0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 309 | 5.0026 / 4.9878 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 309 | 4.6151 / 4.5792 | -0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 309 | 0.68598 / 0.67407 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 309 | 5.0769 / 4.9878 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 309 | 0.91 / 0.91068 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 309 | 1.0202 / 1.0387 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 309 | 4.3669 / 4.3699 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 309 | 0.71898 / 0.67741 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 309 | 5.2864 / 5.2464 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 309 | 4.7277 / 4.7202 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 309 | 4.6741 / 4.6645 | -0.2222222222222222 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
