# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 301 | 4.8124 / 4.8197 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 301 | 5.0368 / 5.0216 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 301 | 0.97926 / 0.96997 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 301 | 0.63977 / 0.63309 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 301 | 0.56725 / 0.56435 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 301 | 4.6767 / 4.7237 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 301 | 0.90736 / 0.88907 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 301 | 0.60496 / 0.55924 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 301 | 4.6684 / 4.7237 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 301 | 4.7642 / 4.8535 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 301 | 0.88245 / 0.89506 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 301 | 0.95795 / 0.96011 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 301 | 4.3346 / 4.3197 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 301 | 0.6122 / 0.62135 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 301 | 4.332 / 4.3317 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 301 | 4.2407 / 4.3431 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 301 | 0.63697 / 0.6216 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 301 | 4.2466 / 4.2229 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 301 | 5.0368 / 5.0216 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 301 | 0.95795 / 0.95767 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 301 | 4.6446 / 4.6998 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 301 | 0.64376 / 0.63245 | -0.22222222222222232 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 301 | 4.516 / 4.6281 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 301 | 0.96997 / 0.97926 | 0.11111111111111116 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
