# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 306 | 0.58559 / 0.58156 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 306 | 0.59622 / 0.59591 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 306 | 4.6263 / 4.6162 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 306 | 0.61058 / 0.61052 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 306 | 4.4862 / 4.5007 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 306 | 0.87661 / 0.86884 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 306 | 4.7914 / 4.7856 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 306 | 4.7894 / 4.7856 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 306 | 0.96701 / 0.9646 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 306 | 4.3933 / 4.3757 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 306 | 4.4757 / 4.455 | -0.2222222222222222 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 306 | 0.58317 / 0.59574 | 0.22222222222222232 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 306 | 0.96701 / 0.97335 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 306 | 0.61878 / 0.61041 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 306 | 4.3837 / 4.3649 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 306 | 4.4613 / 4.4508 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 306 | 0.59566 / 0.59567 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 306 | 0.91905 / 0.92805 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 306 | 4.189 / 4.208 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 306 | 0.92895 / 0.92221 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 306 | 4.5007 / 4.5007 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 306 | 4.6263 / 4.6162 | -0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 306 | 4.2361 / 4.189 | 0.22222222222222215 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 306 | 0.8775 / 0.86861 | -0.11111111111111105 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
