# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 304 | 0.99176 / 0.98685 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 304 | 4.2203 / 4.2614 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 304 | 0.64721 / 0.64851 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 304 | 4.7977 / 4.785 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 304 | 0.64897 / 0.65365 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 304 | 4.2641 / 4.2852 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 304 | 1.0524 / 1.0588 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 304 | 4.6722 / 4.7354 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 304 | 4.505 / 4.455 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 304 | 4.454 / 4.5041 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 304 | 4.7934 / 4.8135 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 304 | 0.99072 / 0.97317 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 304 | 1.0436 / 1.0633 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 304 | 0.61379 / 0.61746 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 304 | 0.62376 / 0.61743 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 304 | 5.0433 / 5.0977 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 304 | 5.0522 / 5.123 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 304 | 0.66914 / 0.67882 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 304 | 0.94961 / 0.94228 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 304 | 4.6142 / 4.703 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 304 | 4.7934 / 4.7934 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 304 | 4.7858 / 4.7877 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 304 | 0.94966 / 0.94254 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 304 | 0.68 / 0.68237 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
