# selection-rule-v1-argmin results

Completed 240 paired comparisons and 793,020 model fits. 240 compute matches; 211 valid endpoint comparisons; 29 inconclusive comparisons. Valid comparisons clearing the fixed +0.05 recall effect: 64.

Conditional recall differences include only valid paired endpoints. All configured seeds remain in the validity denominator. Intervals are descriptive, conditional 95% t intervals across simulation seeds; they are not multiplicity-adjusted or a confirmatory decision.

| n | rho | SNR | T | Valid / total | Valid clearing +0.05 | Conditional recall difference [95% interval] | All-seed MSE difference |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 300 | 0.5 | 0.25 | 2 | 6/10 | 1 | -0.0185 [-0.1063, +0.0693] | +0.00872 |
| 300 | 0.5 | 0.25 | 4 | 7/10 | 3 | +0.0317 [-0.0826, +0.1461] | +0.00123 |
| 300 | 0.5 | 2.0 | 2 | 9/10 | 1 | -0.0123 [-0.0637, +0.0390] | +0.00487 |
| 300 | 0.5 | 2.0 | 4 | 9/10 | 4 | +0.0247 [-0.0465, +0.0959] | +0.00004 |
| 300 | 0.9 | 0.25 | 2 | 6/10 | 2 | +0.0741 [-0.0464, +0.1945] | +0.00522 |
| 300 | 0.9 | 0.25 | 4 | 8/10 | 1 | +0.0139 [-0.0190, +0.0467] | -0.03142 |
| 300 | 0.9 | 2.0 | 2 | 6/10 | 3 | +0.0370 [-0.0582, +0.1322] | +0.01120 |
| 300 | 0.9 | 2.0 | 4 | 9/10 | 3 | +0.0247 [-0.0322, +0.0816] | +0.00419 |
| 1000 | 0.5 | 0.25 | 2 | 8/10 | 2 | -0.0417 [-0.1268, +0.0434] | +0.01747 |
| 1000 | 0.5 | 0.25 | 4 | 8/10 | 4 | +0.0278 [-0.0913, +0.1468] | +0.01412 |
| 1000 | 0.5 | 2.0 | 2 | 10/10 | 2 | -0.0333 [-0.1087, +0.0421] | +0.00206 |
| 1000 | 0.5 | 2.0 | 4 | 10/10 | 2 | -0.0222 [-0.0953, +0.0508] | +0.00254 |
| 1000 | 0.9 | 0.25 | 2 | 8/10 | 2 | -0.0278 [-0.1101, +0.0546] | +0.03756 |
| 1000 | 0.9 | 0.25 | 4 | 9/10 | 3 | +0.0123 [-0.0873, +0.1120] | +0.02613 |
| 1000 | 0.9 | 2.0 | 2 | 10/10 | 5 | +0.0222 [-0.0889, +0.1334] | +0.00255 |
| 1000 | 0.9 | 2.0 | 4 | 10/10 | 4 | +0.0333 [-0.0421, +0.1087] | -0.00220 |
| 3000 | 0.5 | 0.25 | 2 | 10/10 | 4 | +0.0222 [-0.0405, +0.0849] | +0.00048 |
| 3000 | 0.5 | 0.25 | 4 | 10/10 | 2 | -0.0222 [-0.0953, +0.0508] | +0.00343 |
| 3000 | 0.5 | 2.0 | 2 | 10/10 | 3 | +0.0111 [-0.0475, +0.0698] | -0.00028 |
| 3000 | 0.5 | 2.0 | 4 | 10/10 | 3 | +0.0222 [-0.0280, +0.0725] | -0.00067 |
| 3000 | 0.9 | 0.25 | 2 | 9/10 | 4 | +0.0247 [-0.0465, +0.0959] | -0.00592 |
| 3000 | 0.9 | 0.25 | 4 | 9/10 | 2 | -0.0494 [-0.1459, +0.0472] | +0.00537 |
| 3000 | 0.9 | 2.0 | 2 | 10/10 | 1 | -0.0222 [-0.0849, +0.0405] | +0.00269 |
| 3000 | 0.9 | 2.0 | 4 | 10/10 | 3 | +0.0111 [-0.0475, +0.0698] | +0.00056 |

Positive recall differences favor gating; negative loss differences favor gating. The loss diagnostic includes constraint-failing runs and is not a substitute for the qualified endpoint.
No endpoint margin, seed, design or budget was changed during the batch. Full per-arm failure counts, paired uncertainty and raw diagnostics are in paired-summary.csv/json.
