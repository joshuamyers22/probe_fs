# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 307 | 5.6188 / 5.6176 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 307 | 0.66114 / 0.661 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 307 | 1.1786 / 1.1548 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 307 | 0.79179 / 0.79975 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 307 | 0.9157 / 0.85112 | -0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 307 | 6.0405 / 6.0313 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 307 | 0.97123 / 0.98321 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 307 | 0.75141 / 0.74193 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 307 | 5.1984 / 5.2055 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 307 | 0.66346 / 0.66298 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 307 | 1.0983 / 1.1012 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 307 | 1.1637 / 1.1531 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 307 | 5.2056 / 5.205 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 307 | 1.0939 / 1.1108 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 307 | 4.9276 / 4.9183 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 307 | 0.98123 / 0.98837 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 307 | 5.8955 / 5.8583 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 307 | 5.9714 / 5.9546 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 307 | 6.4288 / 6.3579 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 307 | 5.8712 / 5.8603 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 307 | 4.9176 / 4.9172 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 307 | 5.6534 / 5.6029 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 307 | 0.73756 / 0.75257 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 307 | 6.5269 / 6.4408 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
