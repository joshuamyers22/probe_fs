# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 308 | 0.90832 / 0.89832 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 308 | 5.0253 / 5.0562 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 308 | 4.7805 / 4.7872 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 308 | 4.6835 / 4.6776 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 308 | 0.60656 / 0.60625 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 308 | 0.90184 / 0.89283 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 308 | 4.3616 / 4.3307 | -0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 308 | 4.2593 / 4.1903 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 308 | 0.60783 / 0.60557 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 308 | 0.90772 / 0.89832 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 308 | 0.96041 / 0.96425 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 308 | 0.59315 / 0.58669 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 308 | 0.95936 / 0.95984 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 308 | 0.9006 / 0.90263 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 308 | 0.64126 / 0.64401 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 308 | 0.64042 / 0.64475 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 308 | 0.59388 / 0.58679 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 308 | 4.7875 / 4.7805 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 308 | 4.5694 / 4.503 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 308 | 3.942 / 4.1903 | 0.33333333333333326 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 308 | 5.0347 / 5.0263 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 308 | 4.6805 / 4.6776 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 308 | 4.4879 / 4.4928 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 308 | 4.3582 / 4.3251 | -0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
