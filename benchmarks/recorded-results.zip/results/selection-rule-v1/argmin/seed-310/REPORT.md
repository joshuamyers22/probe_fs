# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 310 | 1.1621 / 1.1463 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 310 | 5.4521 / 5.407 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 310 | 4.844 / 4.8504 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 310 | 5.0983 / 5.1037 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 310 | 0.94289 / 0.94972 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 310 | 5.7944 / 5.7552 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 310 | 0.99351 / 0.99899 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 310 | 0.64407 / 0.65074 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 310 | 0.75827 / 0.76112 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 310 | 0.75518 / 0.76891 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 310 | 0.99634 / 0.99857 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 310 | 0.63856 / 0.63373 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 310 | 5.8993 / 5.7552 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 310 | 4.6681 / 4.6706 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 310 | 4.9937 / 5.0048 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 310 | 5.0915 / 5.1068 | 0.22222222222222232 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 310 | 4.6726 / 4.6705 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 310 | 0.63419 / 0.65074 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 310 | 0.94972 / 0.94972 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 310 | 5.3688 / 5.407 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 310 | 4.9998 / 4.9998 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 310 | 1.1463 / 1.1463 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 310 | 0.63468 / 0.63372 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 310 | 4.755 / 4.763 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
