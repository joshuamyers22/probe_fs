# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 303 | 0.88278 / 0.8959 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 303 | 4.4008 / 4.4127 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 303 | 0.5618 / 0.55972 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 303 | 4.7419 / 4.7421 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 303 | 4.0886 / 4.0883 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 303 | 0.5606 / 0.56272 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 303 | 4.4156 / 4.4179 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 303 | 0.87488 / 0.9037 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 303 | 4.083 / 4.0972 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 303 | 4.4127 / 4.4098 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 303 | 0.88916 / 0.88048 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 303 | 0.64602 / 0.62686 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 303 | 0.88868 / 0.88113 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 303 | 4.4483 / 4.4168 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 303 | 4.9322 / 5.0251 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 303 | 0.91781 / 0.9177 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 303 | 4.9883 / 4.984 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 303 | 4.7386 / 4.7355 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 303 | 0.91718 / 0.91753 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 303 | 4.5546 / 4.5804 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 303 | 0.59616 / 0.59682 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 303 | 0.67342 / 0.63552 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 303 | 0.59685 / 0.59633 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 303 | 4.7038 / 4.5804 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
