# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 305 | 0.90096 / 0.90022 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 305 | 4.6071 / 4.6005 | -0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 305 | 3.9345 / 3.9056 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 305 | 1.0237 / 1.0205 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 305 | 4.1489 / 4.1672 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 305 | 0.92215 / 0.90075 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 305 | 4.932 / 4.9203 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 305 | 0.9428 / 0.94361 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 305 | 1.0264 / 1.0165 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 305 | 0.61925 / 0.5978 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 305 | 4.5488 / 4.5562 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 305 | 0.58511 / 0.57813 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 305 | 4.1358 / 4.1672 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 305 | 0.6122 / 0.58172 | -0.33333333333333337 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 305 | 0.58637 / 0.66078 | 0.33333333333333326 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 305 | 0.62226 / 0.62368 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 305 | 4.4976 / 4.462 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 305 | 4.9344 / 4.9203 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 305 | 0.6264 / 0.62411 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 305 | 0.9367 / 0.93864 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 305 | 4.5334 / 4.4901 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 305 | 4.5954 / 4.6163 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 305 | 4.4622 / 4.5041 | -0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 305 | 3.8933 / 3.8841 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
