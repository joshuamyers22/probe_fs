# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 302 | 0.8556 / 0.84509 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 302 | 4.5349 / 4.3015 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 302 | 0.57997 / 0.55563 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 302 | 4.2812 / 3.9688 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 302 | 0.61614 / 0.61795 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 302 | 4.449 / 4.449 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 302 | 5.0007 / 5.018 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 302 | 4.718 / 4.8624 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 302 | 1.0667 / 1.0516 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 302 | 4.449 / 4.4765 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 302 | 0.70919 / 0.70906 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 302 | 4.7493 / 4.7886 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 302 | 0.96246 / 0.96598 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 302 | 4.5349 / 4.4944 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 302 | 0.62791 / 0.62558 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 302 | 1.0466 / 1.011 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 302 | 4.2812 / 3.9688 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 302 | 0.73847 / 0.71819 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 302 | 0.55268 / 0.55577 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 302 | 5.0575 / 5.0575 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 302 | 4.7886 / 4.7886 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 302 | 0.84865 / 0.84509 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 302 | 0.96093 / 0.96246 | -0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 302 | 4.718 / 4.8624 | 0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
