# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 308 | 0.96062 / 0.89832 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 308 | 5.0748 / 5.0723 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 308 | 5.0433 / 5.0433 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 308 | 4.7792 / 4.7863 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 308 | 0.62112 / 0.61476 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 308 | 0.93905 / 0.93905 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 308 | 4.4018 / 4.4018 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 308 | 4.1964 / 4.1871 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 308 | 0.61003 / 0.61822 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 308 | 0.89832 / 0.89832 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 308 | 0.96275 / 0.96368 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 308 | 0.61662 / 0.58444 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 308 | 0.96426 / 0.9668 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 308 | 0.94626 / 0.9452 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 308 | 0.63946 / 0.64401 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 308 | 0.64775 / 0.64401 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 308 | 0.60558 / 0.59948 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 308 | 5.0433 / 5.0433 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 308 | 4.6101 / 4.5717 | -0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 308 | 4.2331 / 4.1978 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 308 | 5.0828 / 5.0723 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 308 | 4.7581 / 4.7689 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 308 | 4.5999 / 4.6277 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 308 | 4.4018 / 4.3797 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
