# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 303 | 1.0338 / 1.0338 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 303 | 4.4203 / 4.431 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 303 | 0.56626 / 0.56626 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 303 | 4.7717 / 4.774 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 303 | 4.0953 / 4.0923 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 303 | 0.57109 / 0.56626 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 303 | 4.4162 / 4.4175 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 303 | 1.0233 / 1.0338 | 0.22222222222222215 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 303 | 4.075 / 4.0893 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 303 | 4.4583 / 4.4281 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 303 | 0.90698 / 0.90698 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 303 | 0.75088 / 0.649 | -0.3333333333333333 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 303 | 0.89799 / 0.90252 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 303 | 4.4471 / 4.4162 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 303 | 5.011 / 4.9517 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 303 | 0.92616 / 0.93017 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 303 | 4.9517 / 5.0399 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 303 | 4.7717 / 4.7812 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 303 | 0.92616 / 0.92616 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 303 | 4.5804 / 4.5804 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 303 | 0.60491 / 0.60542 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 303 | 0.71178 / 0.67652 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 303 | 0.60966 / 0.6049 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 303 | 4.5804 / 4.5804 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
