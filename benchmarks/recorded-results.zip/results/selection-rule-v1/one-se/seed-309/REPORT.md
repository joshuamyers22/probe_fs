# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 309 | 4.6753 / 4.6753 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 309 | 0.60022 / 0.61466 | 0.33333333333333337 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 309 | 1.0205 / 1.0304 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 309 | 1.0205 / 1.038 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 309 | 0.65271 / 0.65182 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 309 | 0.69312 / 0.65182 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 309 | 4.6124 / 4.6124 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 309 | 0.92668 / 0.91974 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 309 | 5.3237 / 5.2823 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 309 | 0.6107 / 0.60404 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 309 | 1.2105 / 1.2638 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 309 | 4.4158 / 4.447 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 309 | 4.8342 / 4.8342 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 309 | 5.1523 / 5.0982 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 309 | 4.6124 / 4.6124 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 309 | 0.66734 / 0.67132 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 309 | 5.1358 / 5.0982 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 309 | 0.91212 / 0.91974 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 309 | 1.1251 / 1.2638 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 309 | 4.4555 / 4.447 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 309 | 0.71225 / 0.67048 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 309 | 5.3419 / 5.2823 | 0.22222222222222215 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 309 | 4.7777 / 4.8035 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 309 | 4.6753 / 4.6753 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
