# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 305 | 0.90886 / 0.92194 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 305 | 4.685 / 4.685 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 305 | 3.8838 / 3.9262 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 305 | 1.0237 / 1.0303 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 305 | 4.1489 / 4.1489 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 305 | 0.92215 / 0.92194 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 305 | 5.0702 / 5.0423 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 305 | 0.95886 / 0.95772 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 305 | 1.0326 / 1.0264 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 305 | 0.6617 / 0.64907 | -0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 305 | 4.5488 / 4.8026 | 0.22222222222222215 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 305 | 0.5853 / 0.59134 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 305 | 4.1489 / 4.1489 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 305 | 0.62962 / 0.58841 | -0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 305 | 0.60196 / 0.65056 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 305 | 0.66314 / 0.64352 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 305 | 4.5488 / 4.5097 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 305 | 5.0118 / 5.0702 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 305 | 0.66213 / 0.66789 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 305 | 0.95886 / 0.95275 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 305 | 4.7124 / 4.7466 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 305 | 4.661 / 4.6994 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 305 | 4.5099 / 4.5097 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 305 | 3.9047 / 3.9047 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
