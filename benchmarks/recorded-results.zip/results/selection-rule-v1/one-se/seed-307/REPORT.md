# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 307 | 5.6501 / 5.6145 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 307 | 0.67736 / 0.68042 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 307 | 1.2117 / 1.2036 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 307 | 0.95664 / 0.86539 | -0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 307 | 0.94301 / 0.8463 | -0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 307 | 5.9193 / 5.9832 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 307 | 1.001 / 0.9994 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 307 | 0.79556 / 0.78645 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 307 | 5.3609 / 5.3191 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 307 | 0.67265 / 0.6718 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 307 | 1.121 / 1.1087 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 307 | 1.2212 / 1.1948 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 307 | 5.3191 / 5.3191 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 307 | 1.1433 / 1.1176 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 307 | 5.0068 / 4.9912 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 307 | 0.9994 / 0.9994 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 307 | 5.8584 / 5.8583 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 307 | 5.9961 / 5.9402 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 307 | 6.5098 / 6.3488 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 307 | 5.8595 / 5.8494 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 307 | 5.0038 / 4.9912 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 307 | 5.6205 / 5.6202 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 307 | 0.78273 / 0.79811 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 307 | 6.4286 / 6.4568 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
