# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 310 | 1.1481 / 1.2111 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 310 | 5.4794 / 5.406 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 310 | 4.864 / 4.8892 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 310 | 5.1208 / 5.2089 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 310 | 0.96264 / 0.96357 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 310 | 5.9348 / 5.9731 | 0.22222222222222215 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 310 | 1.0214 / 1.016 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 310 | 0.68267 / 0.67683 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 310 | 0.76891 / 0.79139 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 310 | 0.76881 / 0.82927 | 0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 310 | 0.99634 / 1.0156 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 310 | 0.64718 / 0.6428 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 310 | 5.9501 / 5.9731 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 310 | 4.7111 / 4.7189 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 310 | 5.0093 / 5.0093 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 310 | 5.1044 / 5.1373 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 310 | 4.6836 / 4.7188 | 0.2222222222222222 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 310 | 0.63462 / 0.67683 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 310 | 0.96226 / 0.96463 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 310 | 5.4491 / 5.406 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 310 | 5.0093 / 5.0093 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 310 | 1.1447 / 1.1463 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 310 | 0.64296 / 0.64288 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 310 | 4.9005 / 4.8565 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
