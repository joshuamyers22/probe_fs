# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 301 | 4.8019 / 4.8089 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 301 | 5.0752 / 5.0752 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 301 | 0.9989 / 0.98074 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 301 | 0.64402 / 0.64402 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 301 | 0.56759 / 0.57135 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 301 | 4.7556 / 4.7687 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 301 | 0.91235 / 0.89878 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 301 | 0.59727 / 0.5646 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 301 | 4.7566 / 4.7734 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 301 | 4.7516 / 4.8089 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 301 | 0.89722 / 0.9044 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 301 | 0.96745 / 0.96352 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 301 | 4.3819 / 4.3694 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 301 | 0.6225 / 0.62781 | 0.2222222222222222 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 301 | 4.3624 / 4.4264 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 301 | 4.2043 / 4.2633 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 301 | 0.63536 / 0.62797 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 301 | 4.2667 / 4.2664 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 301 | 5.0752 / 5.0752 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 301 | 0.96758 / 0.96109 | -0.2222222222222222 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 301 | 4.6423 / 4.6768 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 301 | 0.64663 / 0.64017 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 301 | 4.5638 / 4.7034 | -0.22222222222222215 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 301 | 0.9989 / 0.98074 | -0.11111111111111105 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
