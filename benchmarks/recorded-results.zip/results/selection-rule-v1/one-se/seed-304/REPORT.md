# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 304 | 1.0271 / 1.0217 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 304 | 4.2335 / 4.3073 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 304 | 0.65931 / 0.65703 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 304 | 4.8575 / 4.798 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 304 | 0.69284 / 0.65624 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 304 | 4.2641 / 4.2546 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 304 | 1.1474 / 1.1787 | 0.3333333333333333 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 304 | 4.701 / 4.73 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 304 | 4.5338 / 4.5214 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 304 | 4.5214 / 4.5214 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 304 | 4.7838 / 4.7838 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 304 | 1.0191 / 1.0115 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 304 | 1.169 / 1.1801 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 304 | 0.62464 / 0.6272 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 304 | 0.6272 / 0.6272 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 304 | 5.1042 / 5.1491 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 304 | 5.1491 / 5.1665 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 304 | 0.70099 / 0.73042 | 0.22222222222222215 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 304 | 0.95803 / 0.9581 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 304 | 4.7173 / 4.73 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 304 | 4.7838 / 4.7838 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 304 | 4.7788 / 4.8008 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 304 | 0.95357 / 0.9581 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 304 | 0.70074 / 0.73042 | 0.22222222222222215 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
