# selection-rule-v1-one-se results

Completed 240 paired comparisons and 793,020 model fits. 240 compute matches; 158 valid endpoint comparisons; 82 inconclusive comparisons. Valid comparisons clearing the fixed +0.05 recall effect: 38.

Conditional recall differences include only valid paired endpoints. All configured seeds remain in the validity denominator. Intervals are descriptive, conditional 95% t intervals across simulation seeds; they are not multiplicity-adjusted or a confirmatory decision.

| n | rho | SNR | T | Valid / total | Valid clearing +0.05 | Conditional recall difference [95% interval] | All-seed MSE difference |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 300 | 0.5 | 0.25 | 2 | 7/10 | 2 | +0.0317 [-0.0184, +0.0819] | -0.04036 |
| 300 | 0.5 | 0.25 | 4 | 6/10 | 1 | +0.0000 [-0.1475, +0.1475] | +0.00898 |
| 300 | 0.5 | 2.0 | 2 | 4/10 | 2 | +0.0278 [-0.1415, +0.1971] | -0.01418 |
| 300 | 0.5 | 2.0 | 4 | 3/10 | 0 | -0.0370 [-0.1964, +0.1223] | -0.01647 |
| 300 | 0.9 | 0.25 | 2 | 8/10 | 3 | +0.0278 [-0.0379, +0.0935] | -0.02478 |
| 300 | 0.9 | 0.25 | 4 | 8/10 | 2 | +0.0278 [-0.0152, +0.0708] | -0.00792 |
| 300 | 0.9 | 2.0 | 2 | 3/10 | 0 | -0.1852 [-0.3445, -0.0258] | +0.01723 |
| 300 | 0.9 | 2.0 | 4 | 4/10 | 2 | +0.0278 [-0.1415, +0.1971] | +0.02135 |
| 1000 | 0.5 | 0.25 | 2 | 5/10 | 0 | -0.0444 [-0.1200, +0.0311] | +0.00944 |
| 1000 | 0.5 | 0.25 | 4 | 5/10 | 1 | +0.0222 [-0.0395, +0.0839] | +0.00090 |
| 1000 | 0.5 | 2.0 | 2 | 9/10 | 2 | -0.0123 [-0.0791, +0.0544] | +0.00132 |
| 1000 | 0.5 | 2.0 | 4 | 10/10 | 2 | -0.0000 [-0.0530, +0.0530] | +0.00186 |
| 1000 | 0.9 | 0.25 | 2 | 7/10 | 2 | -0.0000 [-0.0839, +0.0839] | +0.03676 |
| 1000 | 0.9 | 0.25 | 4 | 7/10 | 4 | +0.0794 [+0.0017, +0.1570] | +0.02325 |
| 1000 | 0.9 | 2.0 | 2 | 10/10 | 3 | +0.0222 [-0.0755, +0.1199] | +0.01328 |
| 1000 | 0.9 | 2.0 | 4 | 10/10 | 5 | +0.0778 [-0.0064, +0.1620] | -0.00671 |
| 3000 | 0.5 | 0.25 | 2 | 4/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.00033 |
| 3000 | 0.5 | 0.25 | 4 | 4/10 | 0 | -0.0556 [-0.1576, +0.0465] | +0.00595 |
| 3000 | 0.5 | 2.0 | 2 | 10/10 | 1 | -0.0222 [-0.0725, +0.0280] | -0.00053 |
| 3000 | 0.5 | 2.0 | 4 | 10/10 | 2 | -0.0000 [-0.0649, +0.0649] | +0.00030 |
| 3000 | 0.9 | 0.25 | 2 | 2/10 | 1 | +0.1111 [-1.3007, +1.5229] | -0.00598 |
| 3000 | 0.9 | 0.25 | 4 | 2/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.00637 |
| 3000 | 0.9 | 2.0 | 2 | 10/10 | 2 | +0.0000 [-0.0991, +0.0991] | +0.00073 |
| 3000 | 0.9 | 2.0 | 4 | 10/10 | 1 | -0.0111 [-0.0562, +0.0340] | +0.00238 |

Positive recall differences favor gating; negative loss differences favor gating. The loss diagnostic includes constraint-failing runs and is not a substitute for the qualified endpoint.
No endpoint margin, seed, design or budget was changed during the batch. Full per-arm failure counts, paired uncertainty and raw diagnostics are in paired-summary.csv/json.
