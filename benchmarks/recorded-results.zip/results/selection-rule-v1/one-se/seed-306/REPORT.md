# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 306 | 0.5855 / 0.60519 | 0.22222222222222232 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 306 | 0.64864 / 0.59643 | -0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 306 | 4.6263 / 4.7098 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 306 | 0.63569 / 0.62674 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 306 | 4.5007 / 4.5007 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 306 | 0.87849 / 0.89044 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 306 | 4.8648 / 4.8194 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 306 | 4.8194 / 4.8194 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 306 | 0.96563 / 1.0409 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 306 | 4.473 / 4.434 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 306 | 4.53 / 4.53 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 306 | 0.59236 / 0.60694 | 0.2222222222222222 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 306 | 0.96563 / 1.0409 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 306 | 0.6341 / 0.62804 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 306 | 4.4458 / 4.4703 | 0.22222222222222215 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 306 | 4.53 / 4.5443 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 306 | 0.67018 / 0.60906 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 306 | 0.93577 / 0.94205 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 306 | 4.189 / 4.189 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 306 | 0.94141 / 0.93556 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 306 | 4.5007 / 4.5007 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 306 | 4.6263 / 4.6263 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 306 | 4.189 / 4.189 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 306 | 0.87849 / 0.87849 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
