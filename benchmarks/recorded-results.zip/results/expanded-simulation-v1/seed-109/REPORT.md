# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 109 | 10.503 / 10.606 | -0.22222222222222215 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 109 | 1.8747 / 1.9375 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 109 | 10.771 / 11.1 | 0.2222222222222222 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 109 | 9.1883 / 9.223 | 0.22222222222222215 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 109 | 8.5172 / 8.8491 | 0.44444444444444436 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 109 | 10.811 / 11.1 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 109 | 1.2016 / 1.1958 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 109 | 9.2746 / 9.186 | -0.22222222222222215 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 109 | 1.5072 / 1.318 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 109 | 9.4914 / 9.5552 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 109 | 2.2202 / 2.1853 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 109 | 1.156 / 1.0912 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 109 | 1.8503 / 1.8503 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 109 | 1.8503 / 1.8503 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 109 | 1.1273 / 1.0912 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 109 | 1.331 / 1.318 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 109 | 1.2193 / 1.1958 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 109 | 2.01 / 1.91 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 109 | 10.341 / 10.377 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 109 | 9.5407 / 9.5565 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 109 | 8.7275 / 8.706 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 109 | 8.7337 / 8.7118 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 109 | 8.8222 / 8.8634 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 109 | 2.1589 / 2.2304 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
