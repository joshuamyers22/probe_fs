# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 106 | 1.5572 / 2.0831 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 106 | 1.8575 / 1.8575 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 106 | 9.4586 / 9.5147 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 106 | 9.8224 / 9.8224 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 106 | 9.4566 / 9.0834 | -0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 106 | 9.5147 / 9.4948 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 106 | 9.271 / 9.3808 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 106 | 9.3198 / 9.2967 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 106 | 11.952 / 12.227 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 106 | 1.4763 / 1.5708 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 106 | 1.8575 / 1.8575 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 106 | 1.898 / 1.8003 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 106 | 1.3818 / 1.1907 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 106 | 1.8003 / 1.8003 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 106 | 9.8528 / 9.8224 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 106 | 10.927 / 11.187 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 106 | 9.9275 / 9.0761 | -0.4444444444444444 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 106 | 1.3237 / 1.4893 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 106 | 11.135 / 11.176 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 106 | 1.2339 / 1.2339 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 106 | 2.4024 / 2.5866 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 106 | 12.169 / 12.245 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 106 | 2.4101 / 2.548 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 106 | 1.2339 / 1.2339 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
