# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 110 | 10.034 / 10.009 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 110 | 10.376 / 10.379 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 110 | 10.299 / 10.061 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 110 | 1.3385 / 1.3412 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 110 | 1.293 / 1.2827 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 110 | 9.3743 / 9.5165 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 110 | 1.2335 / 1.2391 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 110 | 9.3807 / 9.5314 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 110 | 1.826 / 1.826 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 110 | 10.049 / 10.049 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 110 | 1.9034 / 1.9034 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 110 | 11.216 / 10.81 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 110 | 9.2327 / 9.3031 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 110 | 1.2357 / 1.2147 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 110 | 1.826 / 1.826 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 110 | 9.4059 / 9.5165 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 110 | 2.0961 / 2.3632 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 110 | 2.2069 / 2.1704 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 110 | 11.216 / 10.786 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 110 | 1.293 / 1.2827 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 110 | 10.049 / 10.049 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 110 | 10.251 / 9.8411 | -0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 110 | 1.3195 / 1.4836 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 110 | 1.9034 / 1.9034 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
