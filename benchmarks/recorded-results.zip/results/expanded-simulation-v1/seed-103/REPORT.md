# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 103 | 10.541 / 10.197 | -0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 103 | 2.0766 / 2.1177 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 103 | 9.5356 / 9.4645 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 103 | 1.7506 / 1.7506 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 103 | 2.0997 / 2.0491 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 103 | 1.4457 / 1.3251 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 103 | 8.7555 / 9.0143 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 103 | 1.198 / 1.1787 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 103 | 9.4256 / 9.804 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 103 | 1.7714 / 1.7714 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 103 | 9.4887 / 9.4645 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 103 | 8.9043 / 9.4171 | 0.33333333333333337 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 103 | 9.4113 / 9.3893 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 103 | 9.4113 / 9.2495 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 103 | 1.386 / 1.4457 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 103 | 1.7714 / 1.7714 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 103 | 8.7004 / 9.0278 | 0.33333333333333326 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 103 | 9.4256 / 9.4511 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 103 | 1.3029 / 1.3029 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 103 | 1.3633 / 1.3029 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 103 | 10.383 / 10.541 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 103 | 9.0736 / 9.309 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 103 | 1.198 / 1.198 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 103 | 1.7506 / 1.7506 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
