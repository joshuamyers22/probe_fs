# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 108 | 1.3289 / 1.2521 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 108 | 1.5138 / 1.3019 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 108 | 9.7957 / 10.713 | 0.2222222222222222 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 108 | 9.7702 / 9.9433 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 108 | 9.5529 / 9.7954 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 108 | 1.6796 / 1.3019 | -0.22222222222222232 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 108 | 9.5374 / 9.4718 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 108 | 1.278 / 1.278 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 108 | 1.8326 / 1.8326 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 108 | 10.536 / 10.832 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 108 | 10.208 / 10.652 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 108 | 9.9418 / 9.9433 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 108 | 1.9158 / 1.9158 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 108 | 1.278 / 1.278 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 108 | 10.347 / 10.423 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 108 | 10.542 / 10.317 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 108 | 1.9158 / 1.9158 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 108 | 1.2521 / 1.2521 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 108 | 1.8326 / 1.8326 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 108 | 1.9914 / 2.0856 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 108 | 2.0108 / 2.155 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 108 | 10.417 / 10.885 | 0.22222222222222215 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 108 | 10.14 / 10.112 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 108 | 10.112 / 10.016 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
