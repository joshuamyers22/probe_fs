# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 107 | 1.3043 / 1.2863 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 107 | 9.3402 / 9.6907 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 107 | 9.4695 / 9.4421 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 107 | 1.322 / 1.2482 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 107 | 10.456 / 9.803 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 107 | 1.7995 / 1.7995 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 107 | 9.6003 / 9.7679 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 107 | 1.1789 / 1.1789 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 107 | 1.9918 / 1.9362 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 107 | 8.7483 / 8.5798 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 107 | 1.7995 / 1.7995 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 107 | 9.0284 / 8.5798 | -0.22222222222222232 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 107 | 9.4824 / 9.3422 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 107 | 10.53 / 10.11 | -0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 107 | 9.0456 / 9.5588 | 0.4444444444444444 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 107 | 10.476 / 10.453 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 107 | 1.6572 / 1.4378 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 107 | 1.1789 / 1.1789 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 107 | 9.7014 / 9.5463 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 107 | 1.4505 / 1.4552 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 107 | 1.8512 / 1.8512 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 107 | 1.9075 / 1.9736 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 107 | 10.399 / 10.453 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 107 | 1.7819 / 1.908 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
