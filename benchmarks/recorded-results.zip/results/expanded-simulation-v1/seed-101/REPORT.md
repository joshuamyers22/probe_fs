# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 101 | 10.488 / 10.562 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 101 | 10.521 / 10.562 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 101 | 1.9863 / 1.9599 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 101 | 1.3037 / 1.4771 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 101 | 1.921 / 1.921 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 101 | 10.227 / 10.491 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 101 | 1.2977 / 1.4827 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 101 | 9.3532 / 9.3532 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 101 | 9.7039 / 9.4314 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 101 | 9.772 / 9.6372 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 101 | 1.2715 / 1.2715 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 101 | 1.8807 / 1.1849 | -0.22222222222222232 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 101 | 10.055 / 10.149 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 101 | 2.3697 / 2.4356 | -0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 101 | 1.921 / 1.921 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 101 | 10.132 / 10.055 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 101 | 1.9599 / 2.0126 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 101 | 2.4592 / 2.4356 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 101 | 9.7878 / 9.7502 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 101 | 1.4271 / 1.2715 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 101 | 1.3448 / 1.1898 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 101 | 9.8675 / 9.4786 | -0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 101 | 9.7293 / 9.3784 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 101 | 10.814 / 10.626 | -0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
