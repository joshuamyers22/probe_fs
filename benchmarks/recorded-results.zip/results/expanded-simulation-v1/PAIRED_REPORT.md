# Expanded simulation results

Completed 240 paired comparisons and 790,320 model fits. 240 compute matches; 79 valid endpoint comparisons; 161 inconclusive comparisons. Valid comparisons clearing the fixed +0.05 recall effect: 1.

Conditional recall differences include only valid paired endpoints. All ten seeds remain in the validity denominator. Intervals are descriptive, conditional 95% t intervals across simulation seeds; they are not multiplicity-adjusted or a confirmatory decision.

| n | rho | SNR | T | Valid / total | Valid clearing +0.05 | Conditional recall difference [95% interval] | All-seed MSE difference |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 300 | 0.5 | 0.25 | 2 | 0/10 | 0 | N/A | +0.00540 |
| 300 | 0.5 | 0.25 | 4 | 0/10 | 0 | N/A | +0.12095 |
| 300 | 0.5 | 2.0 | 2 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | -0.02490 |
| 300 | 0.5 | 2.0 | 4 | 0/10 | 0 | N/A | -0.08150 |
| 300 | 0.9 | 0.25 | 2 | 0/10 | 0 | N/A | -0.21096 |
| 300 | 0.9 | 0.25 | 4 | 0/10 | 0 | N/A | -0.16606 |
| 300 | 0.9 | 2.0 | 2 | 3/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.02276 |
| 300 | 0.9 | 2.0 | 4 | 3/10 | 1 | +0.0370 [-0.1223, +0.1964] | +0.03724 |
| 1000 | 0.5 | 0.25 | 2 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | -0.04850 |
| 1000 | 0.5 | 0.25 | 4 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | +0.00502 |
| 1000 | 0.5 | 2.0 | 2 | 5/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.00739 |
| 1000 | 0.5 | 2.0 | 4 | 7/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.01145 |
| 1000 | 0.9 | 0.25 | 2 | 0/10 | 0 | N/A | +0.03639 |
| 1000 | 0.9 | 0.25 | 4 | 2/10 | 0 | -0.0556 [-0.7615, +0.6503] | +0.05314 |
| 1000 | 0.9 | 2.0 | 2 | 5/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.04577 |
| 1000 | 0.9 | 2.0 | 4 | 6/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.03661 |
| 3000 | 0.5 | 0.25 | 2 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | +0.01020 |
| 3000 | 0.5 | 0.25 | 4 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | -0.00385 |
| 3000 | 0.5 | 2.0 | 2 | 10/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.00000 |
| 3000 | 0.5 | 2.0 | 4 | 10/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.00000 |
| 3000 | 0.9 | 0.25 | 2 | 1/10 | 0 | +0.0000 [insufficient valid seeds] | +0.00065 |
| 3000 | 0.9 | 0.25 | 4 | 3/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.01698 |
| 3000 | 0.9 | 2.0 | 2 | 9/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.02009 |
| 3000 | 0.9 | 2.0 | 4 | 10/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.00766 |

Positive recall differences favor gating; negative loss differences favor gating. The loss diagnostic includes constraint-failing runs and is not a substitute for the qualified endpoint.
No endpoint margin, seed, design or budget was changed during the batch. Full per-arm failure counts, paired uncertainty and raw diagnostics are in paired-summary.csv/json.
