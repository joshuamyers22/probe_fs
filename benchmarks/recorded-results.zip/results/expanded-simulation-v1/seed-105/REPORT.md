# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 105 | 1.264 / 1.2405 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 105 | 9.9852 / 9.9544 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 105 | 1.8108 / 1.8108 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 105 | 9.5891 / 9.3516 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 105 | 8.5321 / 8.6182 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 105 | 8.34 / 8.2892 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 105 | 1.8108 / 1.8108 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 105 | 1.1345 / 1.6815 | 0.33333333333333337 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 105 | 2.0096 / 2.1819 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 105 | 1.2678 / 1.6815 | 0.33333333333333337 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 105 | 1.2708 / 1.2151 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 105 | 9.4119 / 9.233 | -0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 105 | 8.0574 / 8.2866 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 105 | 1.2151 / 1.2151 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 105 | 10.009 / 10.079 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 105 | 1.8559 / 1.9526 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 105 | 1.2697 / 1.2405 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 105 | 10.019 / 10.004 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 105 | 8.5321 / 8.6182 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 105 | 1.8559 / 1.9526 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 105 | 9.7976 / 9.8958 | 0.2222222222222222 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 105 | 2.0643 / 2.1488 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 105 | 9.6046 / 9.3459 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 105 | 9.4573 / 9.233 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
