# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 102 | 1.8073 / 1.8073 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 102 | 1.9948 / 1.9585 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 102 | 10.94 / 10.846 | -1.1102230246251565e-16 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 102 | 9.9225 / 9.94 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 102 | 1.2062 / 1.2062 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 102 | 10.811 / 11.082 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 102 | 1.2997 / 1.459 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 102 | 1.2062 / 1.2062 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 102 | 1.3323 / 1.3034 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 102 | 9.5584 / 9.6491 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 102 | 1.2788 / 1.2788 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 102 | 10.302 / 10.583 | -1.1102230246251565e-16 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 102 | 2.0006 / 2.0626 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 102 | 8.9826 / 8.9647 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 102 | 9.9225 / 9.94 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 102 | 8.9647 / 8.9647 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 102 | 1.318 / 1.3257 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 102 | 9.6181 / 9.6491 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 102 | 10.547 / 10.42 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 102 | 1.8073 / 1.8073 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 102 | 10.497 / 10.42 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 102 | 1.9271 / 2.0626 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 102 | 11.123 / 10.884 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 102 | 1.9585 / 1.9585 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
