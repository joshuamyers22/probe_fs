# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 104 | 12.165 / 12.204 | -0.22222222222222215 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 104 | 1.2054 / 1.1889 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 104 | 8.7993 / 8.7264 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 104 | 1.4619 / 1.6479 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 104 | 1.2752 / 1.2752 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 104 | 1.6866 / 1.4173 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 104 | 9.4516 / 9.4206 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 104 | 1.8332 / 1.8332 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 104 | 9.4664 / 9.6202 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 104 | 2.7507 / 2.4738 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 104 | 10.214 / 10.255 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 104 | 1.8332 / 1.8332 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 104 | 8.8287 / 8.873 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 104 | 11.977 / 12.296 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 104 | 1.8831 / 1.8831 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 104 | 10.214 / 10.255 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 104 | 13.362 / 13.342 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 104 | 13.315 / 13.191 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 104 | 1.2249 / 1.1889 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 104 | 1.8831 / 1.8831 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 104 | 2.4896 / 2.5192 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 104 | 9.652 / 9.895 | 0.33333333333333337 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 104 | 1.2752 / 1.2752 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 104 | 9.5994 / 9.895 | 0.33333333333333337 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
