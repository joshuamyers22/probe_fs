# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 11 | 9.1675 / 9.149 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 29 | 10.535 / 10.888 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 29 | 2.1842 / 2.1468 | 0.0 | True |
| miniboone | 2 | 11 | 0.30389 / 0.30528 | N/A | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 11 | 1.5602 / 1.6485 | -0.11111111111111105 | True |
| superconductivity | 1 | 11 | 420.03 / 400.56 | N/A | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 29 | 10.918 / 10.93 | 0.11111111111111116 | True |
| yearpredictionmsd | 2 | 11 | 100.41 / 100.41 | N/A | True |
| superconductivity | 2 | 11 | 405.49 / 412.93 | N/A | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 11 | 2.1998 / 2.3044 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 11 | 9.3138 / 9.4331 | -0.1111111111111111 | True |
| yearpredictionmsd | 1 | 11 | 100.41 / 102.41 | N/A | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 11 | 9.4106 / 9.5094 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 11 | 1.6444 / 1.4314 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 11 | 2.2736 / 2.2489 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 11 | 9.1703 / 9.2069 | -0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 29 | 10.998 / 11.116 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 29 | 1.3824 / 1.3397 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 29 | 10.662 / 10.88 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 29 | 1.5729 / 1.5782 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 29 | 2.0528 / 2.1347 | 0.11111111111111116 | True |
| miniboone | 1 | 11 | 0.30872 / 0.29885 | N/A | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
