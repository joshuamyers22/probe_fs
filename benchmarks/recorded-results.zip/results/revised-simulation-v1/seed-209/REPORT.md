# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 209 | 6.2075 / 6.1827 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 209 | 1.0037 / 1.0036 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 209 | 4.9584 / 4.9584 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 209 | 1.057 / 1.0382 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 209 | 1.3944 / 1.2249 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 209 | 5.4693 / 5.3406 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 209 | 1.1878 / 1.2249 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 209 | 5.3406 / 5.3406 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 209 | 5.5162 / 5.496 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 209 | 0.99941 / 1.0019 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 209 | 5.0585 / 4.9991 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 209 | 0.68988 / 0.68572 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 209 | 0.79872 / 0.79828 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 209 | 0.69154 / 0.68387 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 209 | 5.2744 / 5.2744 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 209 | 0.6782 / 0.68261 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 209 | 0.88103 / 0.80136 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 209 | 5.2744 / 5.2744 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 209 | 4.9494 / 4.9361 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 209 | 4.9482 / 4.9844 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 209 | 0.68089 / 0.67752 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 209 | 1.057 / 1.0382 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 209 | 5.5038 / 5.496 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 209 | 5.9849 / 6.1827 | -0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
