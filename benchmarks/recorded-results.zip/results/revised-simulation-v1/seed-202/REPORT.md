# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 202 | 4.6202 / 4.6527 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 202 | 1.0022 / 0.92601 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 202 | 4.6615 / 4.6806 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 202 | 0.97113 / 0.99519 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 202 | 1.4423 / 1.4423 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 202 | 0.97649 / 0.98983 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 202 | 5.196 / 5.196 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 202 | 4.8613 / 4.8613 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 202 | 4.8048 / 4.8758 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 202 | 1.0448 / 1.0448 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 202 | 0.67426 / 0.67798 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 202 | 1.0252 / 0.95896 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 202 | 6.4338 / 6.4332 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 202 | 4.9497 / 4.9497 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 202 | 0.67145 / 0.67798 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 202 | 4.9497 / 4.9497 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 202 | 1.2883 / 1.4423 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 202 | 6.5223 / 6.5229 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 202 | 7.0489 / 7.0489 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 202 | 7.0489 / 7.0489 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 202 | 1.0448 / 1.0448 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 202 | 0.632 / 0.63685 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 202 | 5.1864 / 5.2088 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 202 | 0.632 / 0.64131 | 0.2222222222222222 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
