# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 205 | 0.94254 / 0.96822 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 205 | 5.1794 / 5.1794 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 205 | 0.88925 / 0.88751 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 205 | 0.62101 / 0.63267 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 205 | 0.95944 / 0.96317 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 205 | 5.4896 / 5.4834 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 205 | 4.8373 / 4.8373 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 205 | 0.96317 / 0.96317 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 205 | 5.3924 / 5.4834 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 205 | 6.2174 / 6.1288 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 205 | 4.823 / 4.823 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 205 | 1.2411 / 1.2517 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 205 | 0.6454 / 0.64539 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 205 | 6.5413 / 6.2774 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 205 | 4.6116 / 4.6477 | -0.3333333333333333 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 205 | 0.8876 / 0.8817 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 205 | 4.9241 / 4.9101 | 0.22222222222222215 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 205 | 0.96586 / 0.96822 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 205 | 0.65206 / 0.64539 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 205 | 0.63509 / 0.62306 | -0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 205 | 4.9101 / 4.9371 | -0.22222222222222215 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 205 | 5.2084 / 5.1794 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 205 | 4.6452 / 4.6505 | 0.2222222222222222 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 205 | 1.2867 / 1.2945 | 0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
