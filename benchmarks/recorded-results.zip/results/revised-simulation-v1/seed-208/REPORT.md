# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 208 | 4.7844 / 4.8889 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 208 | 0.91238 / 0.90753 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 208 | 0.61836 / 0.59777 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 208 | 0.59777 / 0.60187 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 208 | 4.1752 / 4.558 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 208 | 0.98781 / 0.98781 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 208 | 4.6754 / 4.6754 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 208 | 4.3882 / 4.3882 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 208 | 4.5182 / 4.5182 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 208 | 4.891 / 4.8884 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 208 | 4.6754 / 4.6754 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 208 | 0.98781 / 0.98781 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 208 | 0.65056 / 0.62519 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 208 | 4.5182 / 4.4922 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 208 | 4.5203 / 4.5839 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 208 | 0.90753 / 0.90753 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 208 | 4.3882 / 4.3882 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 208 | 0.64523 / 0.61986 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 208 | 4.5363 / 4.5652 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 208 | 4.1863 / 4.558 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 208 | 0.9192 / 0.91199 | -0.2222222222222222 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 208 | 0.91382 / 0.91199 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 208 | 0.6447 / 0.64307 | 0.1111111111111111 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 208 | 0.64508 / 0.64963 | -0.22222222222222215 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
