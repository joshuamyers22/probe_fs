# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 206 | 1.0224 / 0.98931 | -0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 206 | 0.94109 / 0.93903 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 206 | 0.62444 / 0.62257 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 206 | 5.0862 / 5.0862 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 206 | 5.188 / 5.1577 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 206 | 0.6582 / 0.65792 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 206 | 0.93993 / 0.93993 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 206 | 4.497 / 4.498 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 206 | 0.65784 / 0.65784 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 206 | 0.75274 / 0.74231 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 206 | 4.5076 / 4.497 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 206 | 4.7114 / 4.7135 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 206 | 0.99046 / 1.0224 | 0.2222222222222222 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 206 | 0.74231 / 0.7714 | -0.22222222222222215 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 206 | 1.1075 / 1.11 | -0.22222222222222215 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 206 | 4.8413 / 4.8553 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 206 | 4.6508 / 4.6508 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 206 | 4.8358 / 4.8553 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 206 | 4.7814 / 4.7835 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 206 | 0.62522 / 0.62257 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 206 | 5.0862 / 5.0862 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 206 | 1.1594 / 1.11 | -0.22222222222222215 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 206 | 4.6618 / 4.6618 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 206 | 5.1902 / 5.1577 | 0.1111111111111111 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
