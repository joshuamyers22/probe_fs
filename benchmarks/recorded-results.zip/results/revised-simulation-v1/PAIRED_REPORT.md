# revised-simulation-v1 results

Completed 240 paired comparisons and 792,336 model fits. 240 compute matches; 140 valid endpoint comparisons; 100 inconclusive comparisons. Valid comparisons clearing the fixed +0.05 recall effect: 32.

Conditional recall differences include only valid paired endpoints. All configured seeds remain in the validity denominator. Intervals are descriptive, conditional 95% t intervals across simulation seeds; they are not multiplicity-adjusted or a confirmatory decision.

| n | rho | SNR | T | Valid / total | Valid clearing +0.05 | Conditional recall difference [95% interval] | All-seed MSE difference |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 300 | 0.5 | 0.25 | 2 | 6/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.04404 |
| 300 | 0.5 | 0.25 | 4 | 7/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.00806 |
| 300 | 0.5 | 2.0 | 2 | 4/10 | 0 | -0.0556 [-0.2324, +0.1212] | +0.01862 |
| 300 | 0.5 | 2.0 | 4 | 4/10 | 1 | -0.0278 [-0.2502, +0.1947] | -0.02362 |
| 300 | 0.9 | 0.25 | 2 | 7/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.05640 |
| 300 | 0.9 | 0.25 | 4 | 7/10 | 0 | +0.0000 [+0.0000, +0.0000] | -0.05095 |
| 300 | 0.9 | 2.0 | 2 | 2/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.02469 |
| 300 | 0.9 | 2.0 | 4 | 2/10 | 1 | -0.0556 [-2.1733, +2.0621] | +0.02376 |
| 1000 | 0.5 | 0.25 | 2 | 1/10 | 1 | +0.2222 [insufficient valid seeds] | -0.00977 |
| 1000 | 0.5 | 0.25 | 4 | 3/10 | 0 | -0.0370 [-0.1964, +0.1223] | +0.00131 |
| 1000 | 0.5 | 2.0 | 2 | 7/10 | 5 | +0.1111 [+0.0272, +0.1950] | -0.00674 |
| 1000 | 0.5 | 2.0 | 4 | 7/10 | 2 | -0.0317 [-0.1855, +0.1220] | -0.00001 |
| 1000 | 0.9 | 0.25 | 2 | 4/10 | 0 | -0.0833 [-0.3485, +0.1819] | -0.03397 |
| 1000 | 0.9 | 0.25 | 4 | 5/10 | 1 | +0.0444 [-0.0790, +0.1678] | -0.02170 |
| 1000 | 0.9 | 2.0 | 2 | 10/10 | 6 | +0.0333 [-0.0509, +0.1175] | +0.00312 |
| 1000 | 0.9 | 2.0 | 4 | 10/10 | 3 | +0.0222 [-0.0280, +0.0725] | +0.00202 |
| 3000 | 0.5 | 0.25 | 2 | 4/10 | 0 | -0.0278 [-0.1162, +0.0606] | -0.00819 |
| 3000 | 0.5 | 0.25 | 4 | 4/10 | 0 | -0.0278 [-0.1162, +0.0606] | -0.00479 |
| 3000 | 0.5 | 2.0 | 2 | 10/10 | 3 | +0.0444 [-0.0111, +0.1000] | -0.00159 |
| 3000 | 0.5 | 2.0 | 4 | 10/10 | 3 | +0.0222 [-0.0280, +0.0725] | -0.00352 |
| 3000 | 0.9 | 0.25 | 2 | 3/10 | 0 | -0.0370 [-0.1964, +0.1223] | +0.00152 |
| 3000 | 0.9 | 0.25 | 4 | 3/10 | 0 | +0.0000 [+0.0000, +0.0000] | +0.00114 |
| 3000 | 0.9 | 2.0 | 2 | 10/10 | 2 | -0.0111 [-0.0698, +0.0475] | +0.00287 |
| 3000 | 0.9 | 2.0 | 4 | 10/10 | 4 | +0.0444 [-0.0226, +0.1115] | -0.00335 |

Positive recall differences favor gating; negative loss differences favor gating. The loss diagnostic includes constraint-failing runs and is not a substitute for the qualified endpoint.
No endpoint margin, seed, design or budget was changed during the batch. Full per-arm failure counts, paired uncertainty and raw diagnostics are in paired-summary.csv/json.
