# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 204 | 4.9745 / 5.0177 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 204 | 4.6143 / 4.5894 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 204 | 4.9727 / 5.0137 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 204 | 4.2507 / 4.2621 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 204 | 1.1245 / 1.2191 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 204 | 4.72 / 4.72 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 204 | 0.95278 / 0.96027 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 204 | 0.59986 / 0.60084 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 204 | 4.2586 / 4.269 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 204 | 4.6128 / 4.599 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 204 | 0.84521 / 0.82239 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 204 | 0.96711 / 0.96202 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 204 | 1.1165 / 1.2191 | 0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 204 | 5.8238 / 5.8238 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 204 | 0.82768 / 0.7745 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 204 | 4.7751 / 4.72 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 204 | 5.6793 / 5.6793 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 204 | 0.96202 / 0.96202 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 204 | 0.95593 / 0.96027 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 204 | 5.3133 / 5.2159 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 204 | 5.3337 / 5.4323 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 204 | 0.6006 / 0.59986 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 204 | 0.62534 / 0.62571 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 204 | 0.62567 / 0.62571 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
