# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 210 | 1.0023 / 1.0017 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 210 | 5.1763 / 5.1763 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 210 | 0.65064 / 0.65958 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 210 | 1.0488 / 1.0503 | -0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 210 | 5.1539 / 5.1763 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 210 | 4.7621 / 4.83 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 210 | 4.7785 / 4.8377 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 210 | 1.0424 / 1.0424 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 210 | 1.0424 / 1.0424 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 210 | 4.9251 / 4.9251 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 210 | 5.2541 / 5.238 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 210 | 0.65868 / 0.66539 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 210 | 0.67618 / 0.67491 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 210 | 4.9304 / 4.9122 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 210 | 5.19 / 5.1926 | 0.22222222222222215 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 210 | 4.9141 / 4.9702 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 210 | 5.2243 / 5.2017 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 210 | 0.65972 / 0.67491 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 210 | 1.0463 / 1.0704 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 210 | 4.9702 / 4.9638 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 210 | 0.74791 / 0.74448 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 210 | 5.2541 / 5.238 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 210 | 1.001 / 0.99349 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 210 | 0.73052 / 0.68568 | -0.22222222222222215 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
