# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 201 | 0.96384 / 0.99704 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 201 | 4.9402 / 4.9455 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 201 | 4.8974 / 4.8974 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 201 | 0.64188 / 0.63632 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 201 | 0.98385 / 0.98385 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 201 | 0.69634 / 0.67607 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 201 | 4.9574 / 5.1392 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 201 | 4.4696 / 4.6557 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 201 | 4.538 / 4.5342 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 201 | 0.71428 / 0.67607 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 201 | 4.8974 / 4.8974 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 201 | 0.66679 / 0.66961 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 201 | 4.5497 / 4.5327 | -0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 201 | 0.96542 / 0.96795 | 0.11111111111111105 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 201 | 0.98051 / 0.98385 | 0.11111111111111116 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 201 | 0.92067 / 0.91037 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 201 | 5.317 / 5.3767 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 201 | 4.9478 / 4.9402 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 201 | 0.91725 / 0.91037 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 201 | 0.62944 / 0.63632 | 0.11111111111111116 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 201 | 5.3196 / 5.411 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 201 | 5.096 / 5.1321 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 201 | 0.6697 / 0.67593 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 201 | 4.6557 / 4.6557 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
