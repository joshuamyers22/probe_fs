# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 203 | 4.8672 / 5.002 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 203 | 0.88915 / 0.94296 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 203 | 4.6393 / 4.6069 | -0.3333333333333333 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 203 | 0.63731 / 0.62939 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 203 | 4.5976 / 4.6337 | 0.11111111111111105 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 203 | 3.7177 / 3.7609 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 203 | 3.7609 / 3.7033 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 203 | 0.61545 / 0.61667 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 203 | 0.92701 / 0.9322 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 203 | 0.64135 / 0.6311 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 203 | 4.4748 / 4.4748 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 203 | 0.92614 / 0.92701 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 203 | 4.8811 / 4.899 | -0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 203 | 0.96551 / 0.97114 | 0.11111111111111116 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 203 | 0.62159 / 0.60264 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 203 | 4.2047 / 4.2047 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 203 | 4.7771 / 4.7536 | -0.1111111111111111 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 203 | 4.7771 / 4.7536 | -0.1111111111111111 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 203 | 0.97325 / 0.97114 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 203 | 4.4712 / 4.491 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 203 | 0.94296 / 0.94296 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 203 | 0.60486 / 0.61789 | 0.1111111111111111 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 203 | 0.61321 / 0.61093 | -0.11111111111111105 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 203 | 4.1227 / 4.168 | 0.0 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
