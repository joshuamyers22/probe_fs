# Experiment pilot results

Exploratory feasibility runs; no confirmatory verdict or study stopping decision.

| Dataset/design | Contexts | Seed | Loss gated / ungated | Recall difference | Budget matched |
| --- | --- | --- | --- | --- | --- |
| simulation n=300 rho=0.9 snr=0.25 | 2 | 207 | 5.0173 / 5.0276 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 4 | 207 | 1.0227 / 0.967 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 4 | 207 | 0.91494 / 0.93314 | 0.11111111111111105 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 2 | 207 | 1.0067 / 1.005 | -0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=2.0 | 2 | 207 | 0.91897 / 0.91897 | 0.0 | True |
| simulation n=300 rho=0.5 snr=0.25 | 4 | 207 | 5.1343 / 5.1094 | 0.0 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 2 | 207 | 4.7328 / 4.7938 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 4 | 207 | 0.64034 / 0.63625 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 2 | 207 | 0.60837 / 0.60837 | 0.0 | True |
| simulation n=300 rho=0.5 snr=2.0 | 2 | 207 | 1.0882 / 0.967 | 0.1111111111111111 | True |
| simulation n=300 rho=0.5 snr=0.25 | 2 | 207 | 5.2567 / 5.0596 | 0.1111111111111111 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 2 | 207 | 4.7047 / 4.7047 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=2.0 | 2 | 207 | 0.63651 / 0.63716 | 0.11111111111111116 | True |
| simulation n=3000 rho=0.5 snr=0.25 | 4 | 207 | 4.7328 / 4.7938 | 0.0 | True |
| simulation n=300 rho=0.9 snr=0.25 | 4 | 207 | 4.998 / 5.0276 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 4 | 207 | 5.1694 / 5.1305 | 0.0 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 4 | 207 | 4.4916 / 4.4936 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 2 | 207 | 0.70659 / 0.68863 | 0.2222222222222222 | True |
| simulation n=3000 rho=0.9 snr=0.25 | 2 | 207 | 4.4481 / 4.4487 | 0.0 | True |
| simulation n=300 rho=0.9 snr=2.0 | 4 | 207 | 0.71412 / 0.64479 | -0.44444444444444453 | True |
| simulation n=3000 rho=0.9 snr=2.0 | 4 | 207 | 0.60312 / 0.60404 | 0.0 | True |
| simulation n=1000 rho=0.9 snr=0.25 | 4 | 207 | 4.6951 / 4.6951 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=0.25 | 2 | 207 | 5.1814 / 5.1305 | 0.0 | True |
| simulation n=1000 rho=0.5 snr=2.0 | 4 | 207 | 0.99287 / 1.005 | 0.11111111111111105 | True |

See cell JSON for constraint validity, per-fold selections, rankings, split/context variability, and exact row IDs.
Public data have no known signal classes; recall/false-selection endpoints are not computed.
One importance split cannot estimate variability between importance splits.
Year Prediction results use development rows only; its official test set remains untouched.
